from robocorp.tasks import task
from robocorp import browser

from RPA.HTTP import HTTP
from RPA.Tables import Tables
from RPA.PDF import PDF
from RPA.Archive import Archive

@task
def order_robots_from_RobotSpareBin():
    """
    Orders robots from RobotSpareBin Industries Inc.
    Saves the order HTML receipt as a PDF file.
    Saves the screenshot of the ordered robot.
    Embeds the screenshot of the robot to the PDF receipt.
    Creates ZIP archive of the receipts and the images.
    """
    browser.configure(
        slowmo=300,
    )

    open_robot_order_website()
    close_annoying_modal()
    orders = get_orders()
    process_orders(orders)
    pdf_file = store_receipt_as_pdf(orders)
    screenshot = screenshot_robot(orders)
    embed_screenshot_to_receipt(screenshot, pdf_file)
    go_to_new_order()
    archive_receipts()


def open_robot_order_website():
    """Navigates to the given robot order website URL"""
    browser.goto("https://robotsparebinindustries.com/")


def get_orders():
    """Download order CVS files, read it as a table and returns result"""
    http = HTTP()
    http.download("https://robotsparebinindustries.com/orders.csv", overwrite=True)

    tables = Tables()
    orders = tables.read_table_from_csv("orders.csv")

    return orders


def close_annoying_modal():
    """Close the annoying modal-window"""
    page = browser.page() 
    page.click("text=Order your robot!")
    page.click("xpath=//button[contains(text(), 'OK')]")


def process_orders(orders):
    for row in orders:
        fill_the_form(row)


def fill_the_form(row):
    """Automatically fill out order-form of browser"""

    page = browser.page()

    #Head
    page.select_option("#head", row["Head"])  

    #Body (row["Body"] ist ein String, weil wenn eine CSV-Datei eingelesen wird, dann werden alle Werte standartmäßig als Strings behandelt)
    if(row["Body"] == "1"):
        page.click("text=Roll-a-thor body")
    
    if(row["Body"] == "2"):
        page.click("text=D.A.V.E body")
    
    if(row["Body"] == "3"):
        page.click("text=Spanner mate body")
    
    if(row["Body"] == "4"):
        page.click("text=Peanut crusher body")
    
    if(row["Body"] == "5"):
        page.click("text=Andy Roid body")
    
    if(row["Body"] == "6"):
        page.click("text=Drillbit 2000 body")    

    #Legs (css... spricht genau das Feld an, auch wenn sich die id ändert)
    page.fill("css=input[placeholder='Enter the part number for the legs']", row["Legs"])

    #Address
    page.fill("#address", row["Address"])  
    page.click("text=PREVIEW")

    #Bestellung durchführen
    submit_order()


def submit_order():
    """Submit orders correctly - errors can occur"""
    page = browser.page()
    
    trys = 0
    max_trys = 3
    
    while trys < max_trys:
        page.click("text=ORDER")

        if page.is_visible("text=ERROR"):
            print("Bestellung NICHT erfolgreich! :(")
        else:
            
            print("Bestellung erfolgreich! :)")

        print(f"ERROR! Ausführung konnte nicht erfolgen! Ihre verbleibende Versuchanzahl = ({max_trys - trys})")
        trys += 1

    print("Klick ORDER nochmal! SORRY :()")  

def store_receipt_as_pdf(order_number):
    """Export the data to a pdf file"""
    page = browser.page()
    pdf = PDF()

    pdf_path = f"output/receipts/order_{order_number}.pdf"
    order_results_html = page.locator("#order").inner_html()

    pdf.html_to_pdf(order_results_html, pdf_path)

    return pdf_path


def screenshot_robot(order_number):
    """Take a screenshot of the robot"""
    page = browser.page()
    screenshot_path = f"output/receipts/order_{order_number}.png"
    page.screenshot(path=screenshot_path)

    return screenshot_path


def embed_screenshot_to_receipt(screenshot, pdf_file):
    """Fügt Screenshot der Bestellung an das Ende der PDF-Datei ein"""
    pdf = PDF()
    pdf.add_files_to_pdf(files=[pdf_file, screenshot], target_document=pdf_file)


def go_to_new_order():
    """Klickt auf den Button, um eine neue Bestellung aufzugeben"""
    page = browser.page()
    page.click("text=Order your robot!")

def archive_receipts():
    lib = Archive()
    zip_name = 'receipt_and_screenshot.zip'
    lib.archive_folder_with_zip('./output/receipts', zip_name, recursive=True)
    files = lib.list_archive(zip_name)
    for file in files:
        print(file)